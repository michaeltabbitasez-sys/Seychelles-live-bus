# Getting it running

## Easiest first test: a computer is required for this setup
The ZIP is source code, not an iPhone-installable app. To make it work over the
internet, publish the backend and website separately.

### A. Publish the backend
1. Create a GitHub repository and upload the contents of this project.
2. On a hosting service that supports Python web services (for example Render),
   create a new Web Service connected to that repository.
3. Set the service root directory to `backend`.
4. Build command: `pip install -r requirements.txt`
5. Start command: `uvicorn main:app --host 0.0.0.0 --port $PORT`
6. Deploy and copy the HTTPS service URL, e.g. `https://your-api-host.example`.

### B. Publish the website
1. Edit `web/config.js` and replace `http://localhost:8000` with your backend URL.
2. Upload the `web` folder to a static website host (for example Netlify).
3. Open the resulting HTTPS website URL on your iPhone.
4. In Safari, tap Share -> Add to Home Screen.

### C. Test the independent GPS mode
1. The backend must be deployed and reachable over HTTPS.
2. Open the website on a second phone (or a second browser session).
3. Open Driver mode, enter a test vehicle ID and route, then Start sharing GPS.
4. On the passenger phone, the bus marker should appear and move as the driver phone moves.
5. Stop sharing when the test ends.

## Critical limitations
- This is a development prototype. Driver WebSocket access currently has no login,
  vehicle verification, or access token. Do not expose driver mode publicly or use
  real drivers until authentication and security controls are implemented.
- The wildcard CORS setting is for initial testing only. Restrict it to your site
  domain before production.
- The app does not yet have SPTC's official feed. Obtain SPTC's written approval,
  feed documentation, and credentials before integration.
- The independent GPS demo only shows buses whose drivers deliberately share their
  location. It cannot discover or track ordinary buses automatically.
- The website needs an internet connection for map tiles and live data.
- For iPhone GPS, use the HTTPS hosted site. Browser geolocation is generally not
  available on ordinary non-secure HTTP pages.
