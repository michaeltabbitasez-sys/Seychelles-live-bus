# Seychelles Live Bus — starter prototype

A mobile-first passenger map plus an opt-in driver GPS mode. This is a development
starter, not a deployed or production-ready public transport service.

## What works in this starter
- OpenStreetMap map centred on Mahé.
- Passenger location using the phone's GPS permission.
- Live bus markers received from the backend over WebSockets.
- Driver mode can stream a participating vehicle's phone GPS to the backend.
- No fabricated bus positions: the map clearly says when no live buses are connected.

## What is not connected yet
- SPTC's official live vehicle feed. No public developer API/feed was identified.
  Obtain written permission and API/feed documentation from SPTC before integration.
- Production authentication, driver identity verification, secure hosting, monitoring,
  data retention controls, and App Store packaging.

## Run locally
Requirements: Python 3.10+

```bash
cd backend
python -m venv .venv
# macOS/Linux: source .venv/bin/activate
# Windows: .venv\Scripts\activate
pip install -r requirements.txt
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

Serve the `web` folder from a local web server (not by opening index.html directly).
For example, from the project root:

```bash
python -m http.server 8080 --directory web
```

Open `http://localhost:8080`. For phone GPS testing, use HTTPS on a deployed host;
mobile browsers generally require a secure context for geolocation.

Set `window.BUS_API_BASE` in `web/config.js` to the deployed backend URL.
The passenger map connects to `/ws/passengers`; driver mode connects to
`/ws/driver/{vehicle_id}`.

## SPTC integration plan
1. Contact SPTC and request an authorised developer feed or partner integration.
2. Ask for vehicle positions, route/trip IDs, timestamps, update frequency, terms,
   and a sandbox/test feed.
3. Prefer GTFS static + GTFS-Realtime (VehiclePositions, TripUpdates, Alerts).
4. Implement the authorised feed adapter server-side in `backend/main.py`.
5. Label data source and last update time in the passenger app.

Do not scrape the SPTC app or reverse-engineer private endpoints.

## Privacy and safety
Driver tracking should be enabled only during an active shift, with driver consent.
Do not publish driver names or personal details. Passenger GPS remains on the device
and is not sent to the server in this prototype.
